<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>CodePen - LogIn Form</title>
  <link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Hind:300' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="./css/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<body>
  <!-- partial:index.partial.html -->

  <div id="login-button">
    <img src="./images/sdm_logo.png">
    </img>
  </div>
  <div id="container">
    <h1 style="margin-top:80px;">Log In</h1>
    <div style="text-align: center;">
      <span class="errormsg">
        <?php
        if (isset($_SESSION['error'])) {
          echo $_SESSION['error'];
          session_destroy();
          unset($_SESSION['error']);
        }
        ?>
      </span>
    </div>
    <span class="close-btn">
      <img src="https://cdn4.iconfinder.com/data/icons/miu/22/circle_close_delete_-128.png"></img>
    </span>

    <form action="login_check.php" method="POST">
      <input type="number" placeholder="Username" pattern="[0-9]{6}" maxlength="6" name="username" required autocomplete="off" autofocus>
      <br />
      <input type="password" placeholder="Password" name="password" required>
      <br />
      <button class="form-control btn btn-primary submit px-3" name="save">Sign In</button>

    </form>
  </div>

  <!-- Forgotten Password Container -->

  <!-- partial -->
  <script src='//cdnjs.cloudflare.com/ajax/libs/gsap/1.16.1/TweenMax.min.js'></script>
  <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'>
  </script>
  <script src="./js/script.js"></script>

</body>

</html>
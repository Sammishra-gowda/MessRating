<?php

$conn = new mysqli($servername = "localhost", $username = "root", $password = "", $dbname = "rating");

$connect = new PDO('mysql:host=localhost;dbname=rating', 'root', '');
// if ($conn->connect_error) {
//     die("Connection Failed: " . $conn->connect_error);
// } else {
//     echo "Connection Successful,.!";
// }
$databaseHost = 'localhost';
$databaseName = 'rating';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
?>
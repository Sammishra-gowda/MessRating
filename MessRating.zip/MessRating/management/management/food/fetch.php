<header>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <style>
    .name_edit {
      font-size: 18px;
      font-family:cursive;
    }

    @media only screen and (max-width: 400px) {
      .name_edit{
        font-size:12px;
      }
    }
  </style>
</header>
<?php
session_start();
include('../conn.php');
$hstl_id = $_SESSION['hostel'];
$query = "SELECT * FROM food WHERE hostel_id =$hstl_id  ORDER BY food_id DESC";
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$number_of_rows = $statement->rowCount();
$output = '';
$output .= '
 <table class="table table-bordered table-striped">
  <tr>
   <th class="name_edit">Sr. No</th>
   <th class="name_edit">Category</th>
   <th class="name_edit">Food_item</th>
  
   <th class="name_edit">Delete</th>
  </tr>
';
if ($number_of_rows > 0) {
  $count = 0;
  foreach ($result as $row) {
    $count++;
    $output .= '
  <tr>
   <td class="name_edit">' . $count . '</td>

   <td class="name_edit">' . $row["category"] . '</td>
   <td class="name_edit">' . $row["food_item"] . '</td>
  
   <td class="name_edit"><button type="button" style="font-size:20px" class="btn  btn-xs delete" id="' . $row["food_id"] . '"><i class="material-icons" style="color:red;font-size:20px;">delete</li></button></td>
   </tr>';
  }
} else {
  $output .= '
  <tr>
   <td colspan="6" align="center">No Data Found</td>
  </tr>
 ';
}
$output .= '</table>';
echo $output;

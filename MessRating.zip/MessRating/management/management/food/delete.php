<?php
//delete.php

include('../conn.php');

if (isset($_POST["food_id"])) {

        $query = "DELETE FROM food WHERE food_id = '" . $_POST["food_id"] . "'";
        $statement = $connect->prepare($query);
        $statement->execute();
}

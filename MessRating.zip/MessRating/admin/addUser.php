<?php session_start();?>
<html>

<head>
    <title>Add Data</title>
</head>

<body>
    <?php
    //including the database connection file
    include_once("conn.php");
    $userid = $_POST['id'];
    $password = $_POST['pass'];
    // if (isset($_POST['submit'])) {
    //     $userid = mysqli_real_escape_string($mysqli, $_POST['id']);
    //     $name = mysqli_real_escape_string($mysqli, $_POST['name']);
    //     $password = mysqli_real_escape_string($mysqli, $_POST['pass']);
        

    //     // checking empty fields
    //     if (empty($userid) || empty($name) || empty($password) ) {

    //         if (empty($userid)) {
    //             echo "<font color='red'>User id is empty.</font><br/>";
    //         }

    //         if (empty($name)) {
    //             echo "<font color='red'>Name is empty.</font><br/>";
    //         }
    //         if (empty($password)) {
    //             echo "<font color='red'>Password is empty.</font><br/>";
    //         }

           

    //         //link to the previous page
    //         echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    //     } else {
            // if all the fields are filled (not empty) 

            //insert data to database
            // $hstl_id = $_SESSION['hostel'];	
            $sql = "INSERT INTO users(`name`,hostel_id,`role`,`password`) VALUES($userid,'1','Student','$password')";
            $result = $db->query($sql);
            if ($result === TRUE) {
                ?>
                <script>
                alert("User Data added successfully.");
                window.location.href = "User1.php";
                </script>
                <?php
            }
            else{
                ?>
                <script>
                alert("Cant able to add user data");
                window.location.href = "User1.php";
                </script>
                <?php
            }
            //display success message
            
            echo "<br/><a href='User1.php'>View Result</a>";
    //     }
    // }
    ?>
</body>

</html>
<?php  
include 'conn.php';
// if(isset($_POST['sub']))  
// {   
$checkbox1=$_POST['check'];  
$chk="";  
foreach($checkbox1 as $chk1) {  
    //   $chk .= $chk1.",";
      $sql = "UPDATE food SET status='1' WHERE food_id=$chk1";
        $result = $db->query($sql);   
}  
 
if($result)  
   {  
      ?>
      <script>alert("Data Inserted Successfully");
        window.location.href="index.php";
    </script>;
      <?php  
      
   }  
else  
   {  
    ?>
    <script>alert("Failed to insert data");
      window.location.href="index.php";
  </script>;
    <?php  
   }  

        
?>  
<?php
//delete.php

include('conn.php');
$name = $_GET['name'];
// if (isset($_POST["name"])) {
   
        $query = "DELETE FROM users WHERE `name`='$name'";
        $result = $db->query($query);
            if ($result === TRUE) {
                ?>
                <script>
                alert("User Data deleted successfully.");
                window.location.href = "User1.php";
                </script>
                <?php
            }
            else{
                // $msg="Error: " . $query . "<br>" . $db->error;
                // echo $msg;
                ?>
                <script>
                alert("can't able to delete.");
                window.location.href = "User1.php";
                </script>
                <?php
            }
            ?>
// }

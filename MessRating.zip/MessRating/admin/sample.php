<!DOCTYPE html>
<html>

<head>
    <title>New about space</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
        input,select{
            border-radius: 5px;
        }
        select{
            margin-left: 17px;
            width:210px;
            height:30px;
            -webkit-appearance: none;
            padding:5px;
        }

    </style>
</head>

<body>
    <br />
    <div class="container">

        <h3 align="center" style="font-family:cambria;"><u>Upload Food Menu</u></h3>
        <br />
        <div style="float:right;">
        <button onclick="document.getElementById('id01').style.display='block'" class="w3-button" style="background-color: lightgreen;border-radius:5px;">Add Food</button>
            
        </div>
        <br />
        <br>
        <div class="table-responsive" id="food_table">

        </div>
    </div>
</body>

</html>
<div id="imageModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="edit_food_form">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Edit Image Details</h4>
                </div>
                <div class="modal-body" style="padding:10px;">
                    <div class="form-group">
                        <label>Category</label>
                        <input type="text" name="category" id="category" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Food Item</label>
                        <input type="text" name="food_item" id="food_item" class="form-control" />
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="food_id" id="food_id" value="" />
                    <input type="submit" name="submit" class="btn btn-info" value="Edit" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="w3-container">
    <!-- <h2>W3.CSS Modal</h2>
    <button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-black">Open Modal</button> -->

    <div id="id01" class="w3-modal" >
        <div class="w3-modal-content" style="width:25%;">
            <div class="w3-container" style="padding: 20px;">
                <span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
                <form action="add.php" method="post" name="form1">
                    <!-- <table width="50%" border="0" >
                        <tr>
                            <td>Category : </td>
                            <td><input type="text" name="category"></td>
                        </tr>
                        <tr>
                            <td>Food Item : </td>
                            <td><input type="text" name="food_item"></td>
                        </tr>
                       
                        <tr>
                            <td></td>
                            <td><input type="submit" name="Submit" value="Add"></td>
                        </tr>
                    </table> -->
                    <label>Category : </label>
                    <select>
                        <option hidden>choose</option>
                        <option>Breakfast</option>
                        <option>lunch</option>
                        <option>Dinner</option>
                        <option>Snacks</option>
                    </select><br><br>
                    <!-- <input type="text" style="margin-left: 17px;"/></br></br> -->
                    <label>Food Item : </label>
                    <input type="text" style="margin-left: 5px;"/></br></br>
                    <input type="submit" value="Add"/>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        load_image_data();

        function load_image_data() {
            $.ajax({
                url: "fetch.php",
                method: "POST",
                success: function(data) {
                    $('#food_table').html(data);
                }
            });
        };
        $(document).on('click', '.edit', function() {
            var food_id = $(this).attr("id");
            $.ajax({
                url: "edit.php",
                method: "post",
                data: {
                    food_id: food_id
                },
                dataType: "json",
                success: function(data) {
                    $('#imageModal').modal('show');
                    $('#food_id').val(food_id);
                    $('#category').val(data.category);
                    $('#food_item').val(data.food_item);
                }
            });
        });
        $(document).on('click', '.delete', function() {
            var food_id = $(this).attr("id");
            var category = $(this).data("category");
            if (confirm("Are you sure you want to remove it?")) {
                $.ajax({
                    url: "delete.php",
                    method: "POST",
                    data: {
                        food_id: food_id,
                        category: category
                    },
                    success: function(data) {
                        load_image_data();
                        alert("Image removed");
                    }
                });
            }
        });
        $('#edit_food_form').on('submit', function(event) {
            event.preventDefault();
            if ($('#food_name').val() == '') {
                alert("Enter Image Name");
            } else {
                $.ajax({
                    url: "update.php",
                    method: "POST",
                    data: $('#edit_food_form').serialize(),
                    success: function(data) {
                        $('#imageModal').modal('hide');
                        load_image_data();
                        alert('Image Details updated');
                    }
                });
            }
        });
    });
</script>
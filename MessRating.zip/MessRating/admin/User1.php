<!DOCTYPE html>
<html>

<head>
    <title>New about space</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
  <!-- nice select  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css" integrity="sha512-CruCP+TD3yXzlvvijET8wV5WxxEh5H8P4cmz0RFbKK6FlZ2sYl3AEsKlLPHbniXKSrDdFewhbmBK5skbdsASbQ==" crossorigin="anonymous" />
  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/res-table.css">
    <style>
        input,select{
            border-radius: 5px;
        }
        select{
            margin-left: 17px;
            width:210px;
            height:30px;
            -webkit-appearance: none;
            padding:5px;
        }
        /* body{
            background-image: url('images/hero-bg.jpg');
            background-size: ;
            background-position: center;;
        } */



        table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
tr:nth-of-type(odd) { 
  background: #eee; 
}
th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}
        @media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	/* Force table to not be like tables anymore */
	table, thead, tbody, th, td, tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
        
	}
	th{
        color:black;
    }
	tr { border: 1px solid #ccc; }
	
	td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding: 0; 
	}
	
	td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 0px;
		width: 45%; 
        float: left;
		padding-right: 200px; 
		/* white-space: nowrap; */
	}
	
	/*
	Label the data
	*/
	td:nth-of-type(1):before { content: "User Id"; }
	td:nth-of-type(2):before { content: "User Name"; }
	td:nth-of-type(3):before { content: "Password"; }
	/* td:nth-of-type(4):before { content: "Favorite Color"; }
	td:nth-of-type(5):before { content: "Wars of Trek?"; }
	td:nth-of-type(6):before { content: "Secret Alias"; }
	td:nth-of-type(7):before { content: "Date of Birth"; }
	td:nth-of-type(8):before { content: "Dream Vacation City"; }
	td:nth-of-type(9):before { content: "GPA"; }
	td:nth-of-type(10):before { content: "Arbitrary Data"; } */
}
    </style>
</head>

<body>
    <br />


    <header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.html">
            <span style="color:black;">
              Rate My Food
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav  mx-auto" style="padding-left: 500px;color:black">
              <li class="nav-item active">
                <a class="nav-link" href="index.php"style="color:black;">Home </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="index.php" style="color:black;">Add Menu</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"style="color:orange;">User</a>
              </li>
              
              
            </ul>
            
          </div>
        </nav>
      </div>
    </header>



    <div class="container">

        <h3 align="center" style="font-family:cambria;"><u>Student Details</u></h3>
        <br />
        <div style="float:right;">
        <button onclick="document.getElementById('id01').style.display='block'" class="w3-button" style="background-color: lightgreen;border-radius:5px;">Add User</button>
            
        </div>
        <br />
        <br>
        <div class="table-responsive" id="food_table">

        </div>
    </div>
</body>

</html>
<div id="imageModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="edit_food_form">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Edit Image Details</h4>
                </div>
                <div class="modal-body" style="padding:10px;">
                    <div class="form-group">
                        <label>Category</label>
                        <input type="text" name="category" id="category" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Food Item</label>
                        <input type="text" name="food_item" id="food_item" class="form-control" />
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="food_id" id="food_id" value="" />
                    <input type="submit" name="submit" class="btn btn-info" value="Edit" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="w3-container">
    <!-- <h2>W3.CSS Modal</h2>
    <button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-black">Open Modal</button> -->

    <div id="id01" class="w3-modal" >
        <div class="w3-modal-content" style="width:25%;border-radius:10px;">
            <div class="w3-container" style="padding: 20px;">
                <span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
                <form action="addUser.php" method="post" name="form1">
                    <!-- <table width="50%" border="0" >
                        <tr>
                            <td>Category : </td>
                            <td><input type="text" name="category"></td>
                        </tr>
                        <tr>
                            <td>Food Item : </td>
                            <td><input type="text" name="food_item"></td>
                        </tr>
                       
                        <tr>
                            <td></td>
                            <td><input type="submit" name="Submit" value="Add"></td>
                        </tr>
                    </table> -->
                    <label>User Id : </label>
                    <input type="text" style="margin-left: 30px;" name="id"/>
                    <br><br>
                    <!-- <input type="text" style="margin-left: 17px;"/></br></br> -->
                    <!-- <label>User Name: </label>
                    <input type="text" style="margin-left: 5px;" name="name"/></br></br> -->
                    
                    <label>Password: </label>
                    <input type="password" style="margin-left: 15px;" name="pass"/></br></br>
                    <input type="submit" value="Add" />
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        load_image_data();

        function load_image_data() {
            $.ajax({
                url: "fetch.php",
                method: "POST",
                success: function(data) {
                    $('#food_table').html(data);
                }
            });
        };
        $(document).on('click', '.edit', function() {
            var food_id = $(this).attr("id");
            $.ajax({
                url: "edit.php",
                method: "post",
                data: {
                    food_id: food_id
                },
                dataType: "json",
                success: function(data) {
                    $('#imageModal').modal('show');
                    $('#food_id').val(food_id);
                    $('#category').val(data.category);
                    $('#food_item').val(data.food_item);
                }
            });
        });
        // $(document).on('click', '.delete', function() {
        //     var food_id = $(this).attr("id");
        //     // var category = $(this).data("category");
        //     if (confirm("Are you sure you want to remove it?")) {
        //         $.ajax({
        //             url: "delete.php",
        //             method: "POST",
        //             dataType: "html", 
        //             data: {
        //                 name: food_id
        //             },
        //             success: function(data) {
        //                 load_image_data();
        //                 alert("Image removed");
        //                 $('#msg').html(data);
        //                 $('#table-container').load('fetch-data.php');;
        //             }
        //         });
        //     }
        // });
        $('#edit_food_form').on('submit', function(event) {
            event.preventDefault();
            if ($('#food_name').val() == '') {
                alert("Enter Image Name");
            } else {
                $.ajax({
                    url: "update.php",
                    method: "POST",
                    data: $('#edit_food_form').serialize(),
                    success: function(data) {
                        $('#imageModal').modal('hide');
                        load_image_data();
                        alert('Image Details updated');
                    }
                });
            }
        });
    });
</script>